<!DOCTYPE html>
<html>
<title>SiminiTelecomunicações</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="css/css.css"/>
<link rel="shortcut icon" type="icon/favicon" href="img/logo_semfundo.png"/>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-black.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css"/>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    
<body >
    
    
<script>
// menu tela pequena
function w3_open() {
  var x = document.getElementById("mySidebar");
  x.style.width = "100%";
  x.style.fontSize = "20px";
  x.style.paddingTop = "10%";
  x.style.display = "block";
};
    function w3_close() {
    document.getElementById("mySidebar").style.display = "none";
}
    
  
</script>

<div class="w3-top">
  <div class="w3-bar w3-white w3-card" id="myNavbar">
    <a href="index.php" class="w3-bar-item w3-button w3-wide"><i class="fas fa-home" style="font-size:20px"></i></a>
  
    <div class="w3-right w3-hide-small">
      <a href="#sobre" class="w3-bar-item w3-button"><i class="fa fa-user"></i> Sobre</a>
      <a href="#serviços" class="w3-bar-item w3-button"><i class="fa fa-th"></i> Serviços</a>
      <a href="#contato" class="w3-bar-item w3-button"><i class="fa fa-envelope"></i> Contato</a>
    <?php
        session_start();
        if((isset ($_SESSION['usuarioEmail']))){
            echo"<a href='login/cliente.php' class='w3-bar-item w3-button'><i class='fas fa-user'></i> Área do cliente</a>";

        }else{
            echo"<a href='login/index.php' class='w3-bar-item w3-button'><i class='fas fa-sign-in-alt'></i> Login</a>";
        }
        ?>
    </div>
  

    <a href="javascript:void(0)" class="w3-bar-item w3-button w3-right w3-hide-large w3-hide-medium" onclick="w3_open()">
      <i class="fa fa-bars"></i>
    </a>
  </div>
</div>

<nav class="w3-sidebar w3-bar-block w3-black w3-card w3-animate-left w3-hide-medium w3-hide-large" style="display:none" id="mySidebar">
  <button onclick="w3_close()" class="w3-bar-item w3-button w3-large w3-padding-16" data-toggle="dropdown" >Fechar <i class="fa fa-remove"></i></button>
  <a href="#sobre" onclick="w3_close()" class="w3-bar-item w3-button"  >Sobre</a>
  <a href="#serviços" onclick="w3_close()" class="w3-bar-item w3-button"  >Serviços</a>
  <a href="#contato" onclick="w3_close()" class="w3-bar-item w3-button">Contato</a>
        <?php

        if((isset ($_SESSION['usuarioEmail']))){
            $nome = $_SESSION['usuarioNome'];
            echo"<a href='login/cliente.php' class='w3-bar-item w3-button'> $nome</a>";

        }else{
            echo"<a href='login/index.php' class='w3-bar-item w3-button'> Login</a>";
        }
        ?>
</nav>

<!-- Header -->   
<header id="home" class="w3-display-container w3-animate-opacity" style="background-image: url('img/bg2.jpg');  min-height: 100%; background-position: center; background-size: cover">
 <div class="w3-display-middle">
     <center><img class="w3-animate-top" src="img/logo_semfundo.png" /></center>
  </div>
</header>
    
<br/>
<br/>
<br/>

<!-- Serviços -->
    <br/>
 <section id="serviços">
      <div class="row align-items-center">
        <div class="col-lg-6 order-lg-2">
          <div class="p-5">
            <img class="img-fluid rounded-circle" src="img/servicos.jpg" alt="">
          </div>
        </div>
        <div class="col-lg-6 order-lg-1">
          <div class="p-5">
            <h2 class="display-4">Nossos Serviços</h2>
            <p>A SiminiTelecomunicações, a qual foi fundada em 2010, é uma empresa que trabalha com instalação, programação e manutenção dos serviços de telefonia, interfonia e CFTV (Circuito Fechado de TV - captação e retenção de imagens feita por câmeras digitais ou analógicas e que permite a vídeo-vigilância através de monitores).</p>
          </div>
        </div>
      </div>
<div class="imgs">
    <div class="container">
        <div class="profiles">
      <div class="profile">
        <img src="img/cftv.jpg" class="profile-img">

        <h3 class="user-name">Circuito Fechado de TV</h3>
        <p>Instalamos e programamos câmeras Intelbras.</p>
      </div>
      <div class="profile">
        <img src="img/interfone.jpg" class="profile-img">

        <h3 class="user-name">Centrais de Portaria e Interfonia</h3>
        <p>Instalamos e fazemos a manutenção de interfones Amelco, HDL e Thevear.</p>
      </div>
      <div class="profile">
        <img src="img/telefone1.jpg" class="profile-img">

        <h3 class="user-name">Centrais de Telefonia</h3>
        <p>Instalamos, programamos e fazemos a manutenção de centrais telefônicas das marcas Intelbras, Panasonic e Siemens.</p>
      </div>
    </div>
  </div>
     </div>
 </section>    
    
    <br/>
    

     <div class="services-section">
      <div class="inner-width">
        <h3 class="section-title">Sobre a SiminiTelecomunicações</h3>
        <div class="border"></div>
        <div class="services-container">

          <div class="service-box">
            <div class="service-icon">
              <i class="fas fa-medal"></i>
            </div>
            <div class="service-title"> Qualidade</div>
            <div class="service-desc">
              Nossa empresa preza pela qualidade, portanto, os produtos que utilizamos e instalamos são da mais alta qualidade. 
            </div>
          </div>

          <div class="service-box">
            <div class="service-icon">
              <i class="fas fa-briefcase"></i>
            </div>
            <div class="service-title">Serviços</div>
            <div class="service-desc">
              Nós trabalhamos com Telefonia, Interfonia e Circuito Fechado de Televisão (CFTV).
            </div>
          </div>

          <div class="service-box">
            <div class="service-icon">
              <i class="fas fa-user-check"></i>
            </div>
            <div class="service-title">Atendimento ao Cliente</div>
            <div class="service-desc">
              Solicite o serviço que deseja e faremos a instalação e a programação dele no local a ser combinado pelo cliente.
            </div>
          </div>

          <div class="service-box">
            <div class="service-icon">
               <i class="fas fa-hand-holding-heart"></i>
            </div>
            <div class="service-title">Valores</div>
            <div class="service-desc">
             Nós atuamos com responsabilidade, ética, honestidade, comprometimento e transparência.
            </div>
          </div>
        </div>
      </div>
    </div>
        
    


<!-- Sobre o dono -->
<div class="w3-row w3-padding-64" id="dono">
    <div class="w3-col m6 w3-padding-large">
     <img src="img/david_.png" class="w3-round w3-image w3-opacity-min" alt="David Dente" width="100%" height="auto"/>
    </div>

    <div class="w3-col m6 w3-padding-large">
        <h3 class="w3-center">Conheça o fundador da empresa: David Dente</h3>
        <hr/>
        <p>A SiminiTelecomunicações é uma empresa de telefonia, interfonia e CFTV (Circuito Fechado de TV), que foi fundada em 2010 pelo técnico de interfonia e instalador David Dente, o qual está no ramo há 30 anos. </p>
    </div>
  </div>

    
<!-- Footer -->
<div class="w3-container w3-padding-64" id="contato">
<h2 class="w3-center">Entre em contato conosco!</h2>
<div class="w3-row w3-padding-32">
  <div class="w3-col m6 w3-large w3-margin-bottom">
    <i style="width:30px"> 
    <i class="fas fa-map-marker-alt"></i></i> Localização: Av. Salgado Filho, 3651 - Centro, Guarulhos – Estado de São Paulo<br>
    <i class="fas fa-phone-volume"></i> Telefone: <a style="color:white" target="_blank" href="https://api.whatsapp.com/send?phone=5511991605156">  +55 11 99160-5156 </a><br>
    <i class="fas fa-envelope"></i> siminitelecomunicacoes@gmail.com<br>
    <i class="fab fa-facebook-square"></i> <a style="color:white" target="_blank" href="https://www.facebook.com/Simini-Telecomunica%C3%A7%C3%B5es-100502388577639/"> @siminitelecomunicacoes</a><br/>
    <i class="fab fa-instagram"></i><a style="color:white" target="_blank" href="https://www.instagram.com/simini_telecomunicacoes/"> @simini_telecomunicacoes</a>
  </div>
      <a href="contato/verificaLogin.php"><button class="w3-button w3-yellow w3-section w3-right">Agende um horário aqui!</button></a>
  

</div>
    <p class="w3-center">Desenvolvido por</p> 
    <h4 style="color:#5499C7 ;font-family:Verdana" class="w3-center">Tutte le Stelle</h4>
    
</div>

</body>
</html>
