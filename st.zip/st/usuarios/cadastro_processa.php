<?php

include_once("../conexão.php");
session_start();

$nome = $_POST['nome'];
$email = $_POST['email'];
$senha = md5($_POST['senha']);

$_SESSION['usuarioEmail'] = $email;

$sql = "insert into usuarios (nome,email,senha) value ('$nome','$email','$senha')";
$salvar = mysqli_query($conexao,$sql);

$linhas = mysqli_affected_rows($conexao);

mysqli_close($conexao);
    
        
        if($linhas == 1){
            $_SESSION['cadastroSucesso'] = "Cadastro efetuado com sucesso!";
            $_SESSION['usuarioEmail'] = $email;
            header('Location: ../contato/index.php');
        }        
        else{
            $_SESSION['cadastroErro'] =  "Cadastro NÃO efetuado. <br/> Já existe um usuário com esse e-mail, preencha novamente";
            header('Location: index.php');
        }
        
        ?>
