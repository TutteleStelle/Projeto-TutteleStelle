<?php

$hostname = "localhost";
$user = "root";
$password = "";
$database = "dbst";
$conexao = mysqli_connect($hostname,$user,$password,$database);

define('HOST', 'localhost');
define('USER', 'root');
define('PASS', '');
define('DBNAME', 'dbst');

$conn = new PDO('mysql:host=' . HOST . ';dbname=' . DBNAME . ';', USER, PASS);

if(!$conexao){
    echo "Falha na conexão com o banco de dados";
}

?>