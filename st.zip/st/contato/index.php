<html  xmlns="http://www.w3.org/1999/xhtml">
<title>Entre em contato</title>
<meta charset="UTF-8">
<link rel="shortcut icon" type="icon/favicon" href="../img/logo_semfundo.png"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="../css/formulario.css"/> 
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:400,700&display=swap">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-black.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"/>
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">

<script>
// menu tela pequena
function w3_open() {
  var x = document.getElementById("mySidebar");
  x.style.width = "100%";
  x.style.fontSize = "40px";
  x.style.paddingTop = "10%";
  x.style.display = "block";
}   
</script>

    
<body>
    <div class="banner-img">

<?php
    include '../menu.php';  
    session_start();
?>

    
        <br/>
        <br/>
    
    <div class="container1">
        
            <center>
                <br/>
                <br/>


                <p class="text-center text-success">
                <?php 
                      if(isset($_SESSION['cadastroSucesso'])){
                            echo $_SESSION['cadastroSucesso'];
                            unset($_SESSION['cadastroSucesso']);
                        }
                ?>
                </p>
                </center>
        
        <h3>Preencha os campos a seguir para entrar em contato conosco e agendar um horário:</h3>
        <div class="underline">
        </div>
        <div class="icon_wrapper">
           <i class="fas fa-comments"></i>
        </div>
            <form method="post" action="mailer.php" id="contact_form">
                 <div class="name">
                    <label for="name"></label>
                    <input type="text" placeholder="Nome" maxlength="40" required name="nome" autofocus/>
                </div>
                <div class="email">
                    <label for="cidade"></label>
                    <input type="text" placeholder="E-mail" maxlength="60" required name="email"/>
                </div> 
                <div class="cidade">
                    <label for="cidade"></label>
                    <input type="text" placeholder="Cidade" maxlength="60" required name="cidade"/>
                </div>
                 <div class="bairro">
                    <label for="bairro"></label>
                    <input type="text" placeholder="Bairro" maxlength="60" required name="bairro"/>
                </div>
                 <div class="data">
                    <label for="data">*Não trabalhamos aos domingos</label><br/>
                    <input type="date" required name="dia"/>
                </div>
                <div class="horario">
                   <label for="horario">*Trabalhamos das 08:00 às 18:00</label><br/>
                    <input type="time" min="08:00" max="18:00" required name="horario"/>
                </div>
                <div class="message">
                    <label for="message">Escreva a mensagem para entrar em contato com a SiminiTelecomunicações (Descreva seu problema e serviço desejado):</label>
                    <textarea id="message_input" required name="mensagem" rows="6"></textarea>
                </div>
                <center>
                    <button id="form_button"  type="submit">Enviar</button>   
                    <button id="form_button"  type="reset">Limpar</button> 
            </center>
            </form>
    </div>
    </div>
    
    </body>
    
</html>