<?php

include_once("../conexão.php");

$nome    = $_POST['nome'];
$email   = $_POST['email'];
$cidade  = $_POST['cidade'];
$bairro  = $_POST['bairro'];
$dia    = $_POST['dia'];
$horario = $_POST['horario'];
$mensagem = $_POST['mensagem'];

require_once('../vendor/phpmailer/phpmailer/src/PHPMailer.php');
require_once('../vendor/phpmailer/phpmailer/src/SMTP.php');
require_once('../vendor/phpmailer/phpmailer/src/Exception.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer(true);

try {

	$mail->isSMTP();
	$mail->Host = 'smtp.gmail.com';
	$mail->SMTPAuth = true;
	$mail->Username = 'siminitelecomunicacoes@gmail.com';
	$mail->Password = 'simini2020';
	$mail->Port = 587;

	$mail->setFrom('siminitelecomunicacoes@gmail.com');
	$mail->addAddress('siminitelecomunicacoes@gmail.com');

	$mail->isHTML(true);
	$mail->Subject = 'Agendamento';
	$mail->Body = 'Nome: '. $nome . '<br/> E-mail: '  . $email .  '<br/> Data: '  . $dia .   '<br/> Horário: ' .$horario .'<br/> Cidade: ' . $cidade . '<br/> Bairro: '  . $bairro. '<br/> Mensagem: '  . $mensagem ;
?>



<html>
<title>Confirmação de envio</title>
<meta charset="UTF-8">
<link rel="shortcut icon" type="icon/favicon" href="../img/logo_semfundo.png"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="../css/recado.css"/> 
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-black.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css"/>
    
<script>
// menu tela pequena
function w3_open() {
  var x = document.getElementById("mySidebar");
  x.style.width = "100%";
  x.style.fontSize = "40px";
  x.style.paddingTop = "10%";
  x.style.display = "block";
}   
</script>

   
<body>

<?php
include '../menu.php';    
?>
    
<br/>    
<br/>    
<br/>    
<center>
    <div class="container1 w3-card ">
    <h3>Confirmação de envio de e-mail</h3>
        <div class="underline">
        </div>
        <br/>
        <br/>
        <div class="msg">
        <?php
        if($mail->send()) {
                echo "Email enviado com sucesso! <br/> Confira sua caixa de entrada para a confirmação!";
                
                $query = "INSERT INTO dadosemail (nome,email,cidade,bairro,dia,horario) VALUES ('$nome','$email','$cidade','$bairro','$dia','$horario')"; 
                $result_event = $conexao->query($query);
            
            
            } else {
                echo "Email nao enviado, confira seus dados";
            }
        } catch (Exception $e) {
            echo "Erro ao enviar mensagem: {$mail->ErrorInfo}";
        }
        ?>
        </div>
        
    </div>
  </center>  

</body>
    
</html>