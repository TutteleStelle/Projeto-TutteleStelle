<?php

    $smtpHost   = "smtp.gmail.com";
    $smtpUser   = $_POST['email'];
    $smtpPass   = $_POST['senha'];
    $smtpPort   = "465";
    $smtpAuth   = "SSL";

?>
