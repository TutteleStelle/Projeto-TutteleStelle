<?php  
session_start();
if((isset ($_SESSION['usuarioEmail']))){
        header("Location:index.php");
        echo"logado";
    }else{
        header("Location: ../login/index.php");
        echo"sem login";
}

?>