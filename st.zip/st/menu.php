<head>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-black.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css"/>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">

<script>
// menu tela pequena
function w3_open() {
  var x = document.getElementById("mySidebar");
  x.style.width = "100%";
  x.style.fontSize = "20px";
  x.style.paddingTop = "10%";
  x.style.display = "block";
}   
    
    function w3_close() {
    document.getElementById("mySidebar").style.display = "none";
}
    
</script>
</head>
 
<body>


<!-- Navbar -->
<div class="w3-top">
  <div class="w3-bar w3-white w3-card" id="myNavbar">
    <a href="../index.php" class="w3-bar-item w3-button w3-wide"><i class="fas fa-home" style="font-size:22px"></i></a>
  
    <div class="w3-right w3-hide-small">
      <a href="../index.php#sobre" class="w3-bar-item w3-button"><i class="fa fa-user"></i> Sobre</a>
      <a href="../index.php#trabalho" class="w3-bar-item w3-button"><i class="fa fa-th"></i> Serviços</a>
      <a href="../index.php#contato" class="w3-bar-item w3-button"><i class="fa fa-envelope"></i> Contato</a>
        
    </div>
  

    <a href="javascript:void(0)" class="w3-bar-item w3-button w3-right w3-hide-large w3-hide-medium" onclick="w3_open()">
      <i class="fa fa-bars"></i>
    </a>
  </div>
</div>

<nav class="w3-sidebar w3-bar-block w3-black w3-card w3-animate-left w3-hide-medium w3-hide-large" style="display:none" id="mySidebar">
  <button onclick="w3_close()" class="w3-bar-item w3-button w3-large w3-padding-16" data-toggle="dropdown">Fechar <i class="fa fa-remove"></i></button>
  <a href="../index.php#sobre" onclick="w3_close()" class="w3-bar-item w3-button">Sobre</a>
  <a href="../index.php#trabalho" onclick="w3_close()" class="w3-bar-item w3-button">Serviços</a>
  <a href="../index.php#contato" onclick="w3_close()" class="w3-bar-item w3-button">Contato</a>
</nav>