<?php
include '../../conexão.php';

$query_events = "SELECT id, title, start, end, cliente, email, endereco FROM eventos";
$resultado_events = $conn->prepare($query_events);
$resultado_events->execute();

$eventos = [];

while($row_events = $resultado_events->fetch(PDO::FETCH_ASSOC)){
    $id = $row_events['id'];
    $title = $row_events['title'];
    $start = $row_events['start'];
    $end = $row_events['end'];
    $cliente = $row_events['cliente'];
    $email = $row_events['email'];
    $endereco = $row_events['endereco'];
    
    $eventos[] = [
        'id' => $id, 
        'title' => $title, 
        'start' => $start, 
        'end' => $end,
        'cliente' => $cliente, 
        'email'   => $email,  
        'endereco' => $endereco, 
        ];
}

echo json_encode($eventos);