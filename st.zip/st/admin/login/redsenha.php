<?php
	session_start();
?>
<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <link rel="icon" href="../img/logo_semfundo.png">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css"/>

    <title>Redefinir Senha</title>

    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">
    <link href="css/signin.css" rel="stylesheet">
    <script src="js/ie-emulation-modes-warning.js"></script>
  </head>

  <body>


    <div class="container">

      <form class="form-signin" method="POST" action="validasenha.php">
          <h4 class="form-signin-heading">Digite aqui seu email:</h4>
        <input type="email" name="email" id="email" class="form-control" required/>
          <h4 class="form-signin-heading">Digite aqui sua nova senha:</h4>
        <input type="password" name="senha1" id="inputPassword" class="form-control" required/>
          <h4 class="form-signin-heading">Digite novamente:</h4>
        <input type="password" name="senha2" id="inputPassword" class="form-control" required/>
        <button class="btn btn-lg btn-danger btn-block" type="submit">Redefenir</button>
      </form>
        
	  <p class="text-center text-danger">
			<?php 
          if(isset($_SESSION['senhaErro'])){
				echo $_SESSION['senhaErro'];
				unset($_SESSION['senhaErro']);
			}
          ?>
		</p>
    </div> 



    <script src="js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>

    