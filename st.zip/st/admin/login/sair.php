<?php
	session_start();
	$_SESSION = array();
    $_SESSION['logindeslogado'] = "Conta deslogada com sucesso!"; 
	header("Location: ../index.php");
?>