<?php
	session_start();	

	include_once("../../conexão.php");	
        
        $_SESSION['admEmail'] = mysqli_real_escape_string($conexao, $_POST['email']);
		$_SESSION['senhaNova1'] = mysqli_real_escape_string($conexao, $_POST['senha1']);
		$_SESSION['senhaNova2'] = mysqli_real_escape_string($conexao, $_POST['senha2']);

        $email = $_SESSION['admEmail'];
        $senhanova1 = $_SESSION['senhaNova1'];
        $senhanova2 = $_SESSION['senhaNova2'];

        if($senhanova1 == $senhanova2){
             $nscriptografada = md5($senhanova1);
             $query = "UPDATE adms SET senha = '$nscriptografada' WHERE email = '$email'";
             $result = mysqli_query($conexao, $query);
            
             $_SESSION['senhaSucesso'] = "Sua senha foi alterada com sucesso.";
                header("Location: ../index.php"); 
        }else{
            $_SESSION['senhaErro'] = "Erro ao mudar a senha, as senhas digitadas não são iguais.";
            header("Location: redsenha.php"); 
        }

?>