

<?php
	session_start();	

	include_once("../../conexão.php");	

        $_SESSION['admNome'] = mysqli_real_escape_string($conexao, $_POST['nome']); 
        $_SESSION['admEmail'] = mysqli_real_escape_string($conexao, $_POST['email']); 
		$_SESSION['admSenha'] = mysqli_real_escape_string($conexao, $_POST['senha']);

        $nome = $_SESSION['admNome'];
        $email = $_SESSION['admEmail'];
        $senha = md5($_SESSION['admSenha']);
		
		$query = "SELECT nome,email,nivel FROM adms WHERE email = '$email' && senha = '$senha'";
		$result = mysqli_query($conexao, $query);
        $row = mysqli_num_rows($result);
		
	
        if($row==1){
        while ($row = mysqli_fetch_array( $result )) {
               $_SESSION['nivel'] = $row['nivel'];
               header("Location: ../agendamento/index.php"); 
		      }
        }else{
            $_SESSION['loginErro'] = "Usuário ou senha inválido";
		    $_SESSION['recSenha'] = "Esqueceu sua senha? <br/> Clique <a href='login/recsenha.php'>aqui</a> para recuperação de senha";
            header("Location: ../index.php"); 
    }

?> 