<?php
    session_start();
    if($_SESSION['nivel']==1){
?>

<html>
<title>Cadastrar</title>
<meta charset="UTF-8">
<link rel="shortcut icon" type="icon/favicon" href="../../img/logo_semfundo.png"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" type="text/css" href="css.css"/>
<link rel="stylesheet" href="../menu.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-black.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css"/>
    
<script>
// menu tela pequena
function w3_open() {
  var x = document.getElementById("mySidebar");
  x.style.width = "100%";
  x.style.fontSize = "20px";
  x.style.paddingTop = "10%";
  x.style.display = "block";
}   
     function w3_close() {
        document.getElementById("mySidebar").style.display = "none";
    }
</script>

    
<body>

    
<div class="w3-top">
  <div class="w3-bar w3-card" id="myNavbar">
    <div class="w3-right w3-hide-small">
         <?php
        if($_SESSION['nivel']==1){
            
        ?>
        <a href="../listagem/index.php" class="w3-bar-item w3-button">
            Funcionários
        </a>
        <a href="../agendamento/index.php" class="w3-bar-item w3-button">
            Agenda
        </a>
        <?php
        }
        ?>         
        <a href="../login/sair.php" class="w3-bar-item w3-button">
            Sair
        </a>
    </div>

    <a href="javascript:void(0)" class="w3-bar-item w3-button w3-right w3-hide-large w3-hide-medium" onclick="w3_open()">
      <i class="fa fa-bars"></i>
    </a>
  </div>
</div>

<nav class="w3-sidebar w3-bar-block w3-black w3-card w3-animate-left w3-hide-medium w3-hide-large" style="display:none" id="mySidebar">
        <button onclick="w3_close()" class="w3-bar-item w3-button w3-large w3-padding-16" data-toggle="dropdown" >
            Fechar
            <i class="fa fa-remove"></i>
        </button>
    <?php
        if($_SESSION['nivel']==1){
            
        ?>
    <a href="../listagem/index.php" class="w3-bar-item w3-button"  onclick="w3_close()">
        Funcionários
    </a>
    <a href="../agendamento/index.php" class="w3-bar-item w3-button"  onclick="w3_close()">
        Agenda
    </a>
    <?php
        }
        ?>
    <a href="../login/sair.php" onclick="w3_close()" class="w3-bar-item w3-button">Sair</a>
</nav>
    
<br/>
<br/>
<br/>
<br/>
    
<div class="wrapper">
    <div class="title">
        Cadastro de Funcionários
    </div>
    
    <form method="post" action="cadastro_processa.php">
        <div class="field">
          <input type="text" maxlength="40" required name="nome" placeholder="Nome" autofocus/>
        </div>
        <div class="field">
          <input type="text" maxlength="60" required name="email" placeholder="E-mail"/>
        </div>
        <div class="field">
          <input type="password" maxlength="60" required name="senha" placeholder="Senha"/>
        </div>
        <div class="nivel">
          <label>Nível:</label>
          <select id="nivel" class="w3-input w3-border" name="nivel">
            <option value="1">1 - Controle Geral</option>
            <option value="2">2 - Controle apenas de Agenda</option>
          </select>
        </div>
        <center>
            <div class="btn">
                <input type="submit" value="Cadastrar"/>
            </div>
            <div class="btn">
                <input type="reset" value="Limpar"/>
            </div>
        </center>
        
        </form>
        
        <p class="text-center text-sucess">
        <?php
            if(isset($_SESSION['cadastroAdmSucesso'])){
				echo $_SESSION['cadastroAdmSucesso'];
				unset($_SESSION['cadastroAdmSucesso']);
            }
        ?>
        </p>
        
         <p class="text-center text-danger">
        <?php 
             
            if(isset($_SESSION['cadastroAdmErro'])){
				echo $_SESSION['cadastroAdmErro'];
				unset($_SESSION['cadastroAdmErro']);
            };
    
            if(isset($_SESSION['cadastroAdmErro1'])){
				echo $_SESSION['cadastroAdmErro1'];
				unset($_SESSION['cadastroAdmErro1']);
            }?>
        </p>
    </div> 

</body>
    
</html>

<?php
    }else{
        header('Location: ../index.php');
    }
?>