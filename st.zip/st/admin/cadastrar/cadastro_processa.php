 <?php
        include_once("../../conexão.php");
        session_start();

        $nome = $_POST['nome'];
        $email = $_POST['email'];
        $senha = md5($_POST['senha']);
        $nivel = $_POST['nivel'];

        $sql_adm = "SELECT * FROM adms WHERE nome = '{$nome}' and email= '{$email}'";
        $query = mysqli_query($conexao,$sql_adm);
        $row = mysqli_affected_rows($conexao);

        if($row == 0){
            $sql = "INSERT INTO adms (nome,email,senha,nivel) VALUES ('$nome','$email','$senha','$nivel')";
            $salvar = mysqli_query($conexao,$sql);
            $linhas = mysqli_affected_rows($conexao);
        
            if($linhas == 1){
                $_SESSION['cadastroAdmSucesso'] = "Cadastro efetuado sucesso!";
                header ("Location: index.php");
            }else{
                $_SESSION['cadastroAdmErro'] = "Cadastro não efetuado";
                header ("Location: index.php");
                }
    }else{
         $_SESSION['cadastroAdmErro1'] = "Cadastro não efetuado. <br/> Já existe um administrador com esses dados, preencha novamente";
         header ("Location: index.php");
    }
        
?>
