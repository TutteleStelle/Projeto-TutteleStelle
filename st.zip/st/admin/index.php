<?php
	session_start();
?>
<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <link rel="icon" href="../img/logo_semfundo.png">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css"/>

    <title>Login</title>

    <link href="login/css/bootstrap.css" rel="stylesheet">
    <link href="login/css/ie10-viewport-bug-workaround.css" rel="stylesheet">
    <link href="login/css/signin.css" rel="stylesheet">
    <script src="js/ie-emulation-modes-warning.js"></script>
  </head>

  <body>


    <div class="container">

      <form class="form-signin" method="POST" action="login/valida.php">
        <h2 class="form-signin-heading">Login</h2>
        <input type="text" name="nome" id="inputNome" class="form-control" placeholder="Nome" required autofocus/>
        <input type="email" name="email" id="inputEmail" class="form-control" placeholder="Email" required/>
        <input type="password" name="senha" id="inputPassword" class="form-control" placeholder="Senha" required/>
        <button class="btn btn-lg btn-warning btn-block" type="submit" style="color:black">Acessar</button>
      </form>
        
	  <p class="text-center text-danger">
			<?php 
          if(isset($_SESSION['loginErro'])){
				echo $_SESSION['loginErro'];
				unset($_SESSION['loginErro']);
			}
			if(isset($_SESSION['emailErro'])){
				echo $_SESSION['emailErro'];
				unset($_SESSION['emailErro']);
			}
			if(isset($_SESSION['emailErro1'])){
				echo $_SESSION['emailErro1'];
				unset($_SESSION['emailErro1']);
			}
			if(isset($_SESSION['erroEmail'])){
				echo $_SESSION['erroEmail'];
				unset($_SESSION['erroEmail']);
			}
          ?>
		</p>
        <p class="text-center">
			<?php 
			if(isset($_SESSION['recSenha'])){
				echo $_SESSION['recSenha'];
				unset($_SESSION['recSenha']);
			}
			?>
        </p>
		<p class="text-center text-success">
			<?php 
			if(isset($_SESSION['logindeslogado'])){
				echo $_SESSION['logindeslogado'];
				unset($_SESSION['logindeslogado']);
			}
            if(isset($_SESSION['emailSucesso'])){
				echo $_SESSION['emailSucesso'];
				unset($_SESSION['emailSucesso']);
			}
            if(isset($_SESSION['senhaSucesso'])){
				echo $_SESSION['senhaSucesso'];
				unset($_SESSION['senhaSucesso']);
			}
			?>
		</p>
    </div> 


    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>
