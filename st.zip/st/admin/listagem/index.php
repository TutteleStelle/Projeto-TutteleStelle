<?php
    session_start();
    if($_SESSION['nivel']==1){
?>

<html>
<title>Cadastrar</title>
<meta charset="UTF-8">
<link rel="shortcut icon" type="icon/favicon" href="../../img/logo_semfundo.png"/>
<link rel="stylesheet" href="../menu.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-black.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css"/>
    
<script>
// menu tela pequena
function w3_open() {
  var x = document.getElementById("mySidebar");
  x.style.width = "100%";
  x.style.fontSize = "20px";
  x.style.paddingTop = "10%";
  x.style.display = "block";
}   
     function w3_close() {
        document.getElementById("mySidebar").style.display = "none";
    }
</script>

<style>
 .fas {font-family: 'FontAwesome'! Important; color:#FF0000; font-size: 25px;}
 .fas:hover{color:#8A0808 }
    .container a{text-decoration: none}
</style>
    
<body>

<br/>

<div class="w3-top">
  <div class="w3-bar w3-card" id="myNavbar">
  
    <div class="w3-right w3-hide-small">
        <?php
            if($_SESSION['nivel']==1){
        ?>
        <a href="../cadastrar/index.php" class="w3-bar-item w3-button">
            Cadastrar
        </a>
        <a href="../agendamento/index.php" class="w3-bar-item w3-button">
            Agenda
        </a>
        <?php
            }
        ?>
      <a href="../login/sair.php" class="w3-bar-item w3-button">
          Sair
        </a>
    </div>
  
    <a href="javascript:void(0)" class="w3-bar-item w3-button w3-right w3-hide-large w3-hide-medium" onclick="w3_open()">
      <i class="fa fa-bars"></i>
    </a>
  </div>
</div>

<nav class="w3-sidebar w3-bar-block w3-black w3-card w3-animate-left w3-hide-medium w3-hide-large" style="display:none" id="mySidebar">
  <button onclick="w3_close()" class="w3-bar-item w3-button w3-large w3-padding-16" data-toggle="dropdown" >
            Fechar
            <i class="fa fa-remove"></i>
    </button>
    <?php
            if($_SESSION['nivel']==1){
        ?>
    <a href="../cadastrar/index.php" class="w3-bar-item w3-button"  onclick="w3_close()">
        Cadastrar
    </a>
    <a href="../agendamento/index.php" class="w3-bar-item w3-button"  onclick="w3_close()">
        Agenda
    </a>
    <?php
            }
    ?>
  <a href="../login/sair.php" onclick="w3_close()" class="w3-bar-item w3-button">
      Sair
    </a>
</nav>
    
<br/>
<br/>
    
<center>
    <div class="container">
    <h2>Administradores</h2>
        
        <p class="text-center text-success">
        <?php
            if(isset($_SESSION['deleta'])){
				echo $_SESSION['deleta'];
				unset($_SESSION['deleta']);
            }
        ?>
        </p>
        
        <table class="w3-table w3-bordered w3-card-4">
        <tr>
            <th>Funcionário</th>
            <th>E-mail</th>
            <th>Nível de Acesso</th>
            <th>Excluir</th>
            
         </tr>
        <?php
         include_once("../../conexão.php");
        
        $sql = "SELECT nome,email,nivel FROM adms ";
        $query = mysqli_query($conexao,$sql);
        
        while($fetch = mysqli_fetch_row($query)){
            $_SESSION['emailDeleta'] = $fetch[1];
            echo "<tr><td>" .$fetch[0]. "</td>";
            echo "<td>" .$fetch[1]. "</td>";
            echo "<td>" .$fetch[2]. "</td>";
            echo "<td><a href='deleta.php'><i class='fas fa-user-times'></i></a></td></tr>";
            }
        ?>
        </table>
        
        
    </div>
  </center>  

</body>
    
</html>

<?php
    }else{
        header('Location: ../index.php');
    }
?>