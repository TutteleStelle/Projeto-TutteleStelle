<?php
include_once '../../conexão.php';
session_start();

$email = $_SESSION['emailDeleta'];
    
$sql = "DELETE FROM adms WHERE email = '{$email}' ";
$query = mysqli_query($conexao,$sql);

$_SESSION['deleta'] = "O funcionário foi excluído com sucesso!";
header("Location: index.php");

?>
