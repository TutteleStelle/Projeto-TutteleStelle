CREATE DATABASE dbST CHARSET utf8;

use dbST;

DROP TABLE IF EXISTS usuarios;
CREATE TABLE usuarios (
	id_usuario 	int not null auto_increment,
    nome		varchar(50) not null,
    email		varchar(60) not null,
    senha		varchar(50) not null,
    PRIMARY KEY (id_usuario)
);

DROP TABLE IF EXISTS eventos;
CREATE TABLE IF NOT EXISTS eventos (
  id int(11) NOT NULL AUTO_INCREMENT,
  title varchar(220) DEFAULT NULL,
  start datetime DEFAULT NULL,
  end datetime DEFAULT NULL,
  cliente	text not null,
  email		varchar(60) not null, 
  endereco  varchar(100) not null,
  PRIMARY KEY (`id`)
) ;

DROP TABLE IF EXISTS adms;
CREATE TABLE IF NOT EXISTS adms(
  nome		varchar(40) not null,
  email		varchar(60) not null, 
  senha  varchar(40) not null,
  nivel  int(11)
) ;

DROP TABLE IF EXISTS dadosemail;
CREATE TABLE IF NOT EXISTS dadosemail(
  nome		varchar(40) not null,
  email		varchar(60) not null, 
  cidade    varchar(60) not null,
  bairro    varchar(60) not null,
  dia       date,
  horario   time
) ;