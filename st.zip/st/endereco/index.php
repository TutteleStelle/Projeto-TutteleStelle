<html>
<title>Finalizar agendamento</title>
<meta charset="UTF-8">
<link rel="shortcut icon" type="icon/favicon" href="../img/logo_semfundo.png"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="../css/formulario.css"/> 
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-black.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css"/>
    
<?php
include "../menu.php";
?>    
    
<body>
      <div class="banner-img">
          <br/>
          <br/>
        <div class="container2">
        <h3>Insira seu endereço:</h3>
        <div class="underline">
        </div>
        
        <form method="post" id="contact_form" action="guardar_endereco.php">
            <div class="endereco">
                <label class="email"></label>
                <input type="email" placeholder="Email" maxlength="60" required name="email" autofocus/>
            </div>
            <div class="endereco">
                <label class="rua"></label>
                <input type="text" placeholder="Rua" maxlength="50" required name="rua"/>
            </div>
             <div class="endereco">
                <label class="numero"></label>
                <input type="number" placeholder="Número" required name="numero"/>
            </div>
             <div class="endereco">
                <label class="complemento"></label>
                <input type="text" placeholder="Complemento" maxlength="80" name="complemento"/>
            </div>
            <center>
                <button id="form_button" type="submit">Enviar</button>   
                <button id="form_button" type="reset">Limpar</button>   
            </center>

        </form>
        
    </div>
    </div>

</body>
    
</html>