<?php
session_start();
include "../menu.php";
include "../conexão.php";
                            
        $email = $_POST["email"];
        $rua = $_POST["rua"];
        $numero = $_POST["numero"];
        $complemento = $_POST["complemento"];

require_once('../vendor/phpmailer/phpmailer/src/PHPMailer.php');
require_once('../vendor/phpmailer/phpmailer/src/SMTP.php');
require_once('../vendor/phpmailer/phpmailer/src/Exception.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer(true);

try {

	$mail->isSMTP();
	$mail->Host = 'smtp.gmail.com';
	$mail->SMTPAuth = true;
	$mail->Username = 'siminitelecomunicacoes@gmail.com';
	$mail->Password = 'simini2020';
	$mail->Port = 587;

	$mail->setFrom('siminitelecomunicacoes@gmail.com');
	$mail->addAddress('siminitelecomunicacoes@gmail.com');

	$mail->isHTML(true);
	$mail->Subject = 'Endereco-'. $email ;
	$mail->Body = 'Endereço: '. $rua . ',' .$numero. '<br/>' .$complemento;

?>


<html>
<title>Finalizar agendamento</title>
<meta charset="UTF-8">
<link rel="shortcut icon" type="icon/favicon" href="../img/logo_semfundo.png"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="../css/recado.css"/> 
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css"/>

<body> 
<center>
<div class="container1 w3-card ">

    <h3>Confirmação de agendamento</h3>
        <div class="underline">
        </div>
        <br/>
        <br/>
        <div class="msg">
        
        <?php
        
        if($mail->send()){
            
            $query = "SELECT nome,cidade,bairro,dia,horario FROM dadosemail WHERE email = '$email'";
            $result = $conexao->query($query);
            
            while($row = $result->fetch_assoc()){
            $cliente = $row['nome'];
            $cidade = $row['cidade'];
            $bairro = $row['bairro'];
            $dia = $row['dia'];
            $horario = $row['horario'];
            
            
            $endereco = $cidade. ", ".$bairro. " - " .$rua. ", " .$numero. " - " .$complemento;        
            $start = $dia. " " .$horario;
                      
                $horario_segundos = array($horario);
                $horas = 0;
                $minutos = 0;
                $segundos = 0;

                foreach ( $horario_segundos as $tempo ){ 
                list( $h, $m, $s ) = explode( ':', $tempo ); 


                $horas += $h * 3600 + 3600;
                $minutos += $m * 60;
                $segundos += $s;

                }

                $horas = floor( $horas / 3600 ); 
                $horas %= 3600; 
                $minutos = floor( $minutos / 60 );
                $segundos %= 60;

                $horario_end = "{$horas}:{$minutos}:{$segundos}";

                
            $end = $dia. " " .$horario_end;

            $query_event = "INSERT INTO eventos (start, end, cliente, email, endereco) VALUES('$start','$end','$cliente','$email','$endereco')";
            $result_event = $conexao->query($query_event);
                
                print "Agendamento realizado com sucesso!";  
                $_SESSION['usuarioEmail'] = $email;
            }
        }        
        else{
            print "Agendamento NÃO efetuado. <br/> Verifique os dados inseridos.";
        }
        } catch (Exception $e) {
            echo "Erro ao enviar os dados: {$mail->ErrorInfo}";
}
        ?>
    
  </div>
    </div>
</center>
</body>
</html>