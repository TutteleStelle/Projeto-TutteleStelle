<head>
<title>Login</title>
<link rel="shortcut icon" type="icon/favicon" href="../img/logo_semfundo.png"/>
<link rel="stylesheet" type="text/css" href="css/css1.css">
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css"/>

</head>


<body>
    
<?php
include_once '../menu.php';
session_start();
?>

<br/>
<section class="login-block">
    <div class="container">
	<div class="row">
		<div class="col-md-4 login-sec">
		    <h2 class="text-center">Login</h2>
                <form class="login-form" method="POST" action="valida.php">
                      <div class="form-group">
                        <label for="exampleInputEmail1" class="text-uppercase">E-mail</label>
                        <input type="email" name="email" class="form-control" placeholder="Digite seu e-mail">

                      </div>
                      <div class="form-group">
                        <label for="exampleInputPassword1" class="text-uppercase">Senha</label>
                        <input type="password" name="senha" class="form-control" placeholder="Digite sua senha">
                      </div>
                    
                    <button type="submit" class="btn btn-login float-right">Acessar</button>
                   
<br/>
                <div id="msg">
                    <p class="text-danger">
                    <?php 
                    if(isset($_SESSION['loginErro'])){
                        echo $_SESSION['loginErro'];
                        unset($_SESSION['loginErro']);
                    }
                    if(isset($_SESSION['emailErro1'])){
                        echo $_SESSION['emaiilErro1'];
                        unset($_SESSION['emaiilErro1']);
                    }
                    if(isset($_SESSION['emailErro'])){
                        echo $_SESSION['emaiilErro'];
                        unset($_SESSION['emaiilErro']);
                    }
                    if(isset($_SESSION['erroEmail'])){
                        echo $_SESSION['erroEmail'];
                        unset($_SESSION['erroEmail']);
                    }
                  ?>
                </p>
                    
            <p class="text-success">
                <?php 
                if(isset($_SESSION['logindeslogado'])){
                    echo $_SESSION['logindeslogado'];
                    unset($_SESSION['logindeslogado']);
                }
                if(isset($_SESSION['emailSucesso'])){
                    echo $_SESSION['emailSucesso'];
                    unset($_SESSION['emailSucesso']);
                }
                ?>
            </p>
        </div>

</form>
<br/>
<div class="copy-text"><p>Se você não possui um cadastro, clique <a href="../usuarios/index.php">aqui</a> para criar.</p></div>
        </div>
        
		<div class="col-md-8 banner-sec">
            
            <div class="d-none d-md-block">
                <div class="banner-text">
                    <h2>SiminiTelecomunicações</h2>
                    <p>Interfonia, Telefonia e Assistência técnica</p>
                </div>	
            </div>	  
		</div>
	</div>
        </div>
    </section>
</body>