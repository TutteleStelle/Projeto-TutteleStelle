<?php
	session_start();
	$_SESSION = array();
	//redirecionar o usuario para a página de login
	header("Location: index.php");
?>