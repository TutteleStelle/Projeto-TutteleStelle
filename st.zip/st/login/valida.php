<?php
	session_start();	

	include_once("../conexão.php");	

	if((isset($_POST['email'])) && (isset($_POST['senha']))){
        $usuario = mysqli_real_escape_string($conexao, $_POST['email']); 
		$senha = mysqli_real_escape_string($conexao, md5($_POST['senha']));
        $_SESSION['usuarioEmail'] = $usuario;
		
		$query = "SELECT email FROM usuarios WHERE email = '$usuario' && senha = '$senha'";
		$result = mysqli_query($conexao, $query);
        $row = mysqli_num_rows($result);
		
	
        if($row==1){
        while ($row = mysqli_fetch_array( $result )) {
            header("Location: cliente.php");
		}
            
        }else{
		$_SESSION['loginErro'] = "Usuário ou senha inválido <br/> Não lembra a sua senha? Clique <a style='color:#2E2EFE' href='recsenha.php'>aqui</a> para a redefinição";
		header("Location: index.php");
        }
	
    }
?> 