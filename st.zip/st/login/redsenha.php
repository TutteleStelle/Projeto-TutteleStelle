<?php
	session_start();
?>
<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
     <link rel="stylesheet" href="css/redsenha.css">
    <link rel="icon" href="../img/logo_semfundo.png">

    <title>Redefinir Senha</title>
  </head>

<body>
    <form class="box" method="POST" action="validasenha.php">
        <h2>Redefinir Senha:</h2>
          <p>Digite aqui seu email:</p>
            <input type="email" name="email" required/>
          <p>Digite aqui sua nova senha:</p>
            <input type="password" name="senha1" required/>
          <p>Digite novamente:</p>
            <input type="password" name="senha2" required/>
          <input type="submit" value="OK"/>
        <p class="text-center">
			<?php 
          if(isset($_SESSION['senhaErro'])){
				echo $_SESSION['senhaErro'];
				unset($_SESSION['senhaErro']);
			}
          ?>
		</p>
      </form>
        

  </body>
</html>

    