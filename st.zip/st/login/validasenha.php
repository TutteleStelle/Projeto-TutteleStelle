<?php
	session_start();	

	include_once("../conexão.php");	
        

        $email = $_POST['email'];
        $senhanova1 = $_POST['senha1'];
        $senhanova2 = $_POST['senha2'];

        if($senhanova1 == $senhanova2){
            $consulta = "select id_usuario from usuarios where email = '$email' ";
            $registros = mysqli_query($conexao, $consulta);
            $linha = mysqli_num_rows($registros);
                
            if( $linha == 1){
                $nscriptografada = md5($senhanova1);
                $query = "UPDATE usuarios SET senha = '$nscriptografada' WHERE email = '$email'";
                $result = mysqli_query($conexao, $query);
            
                if($result=1){
                    $_SESSION['senhaSucesso']  = "Senha alterada com sucesso!";
                    header("Location: cliente.php");
                    }
            }else{
                $_SESSION['senhaErro'] = "Erro ao mudar a senha, esse e-mail não está cadastrado.";
                header("Location: redsenha.php"); 
                }
        }else{
            $_SESSION['senhaErro'] = "Erro ao mudar a senha, as senhas inseridas não coincidem.";
            header("Location: redsenha.php"); 
            }

?>