<head>
    <meta charset='utf-8' />
    <link href='css/core/main.min.css' rel='stylesheet' />
    <link href='css/daygrid/main.min.css' rel='stylesheet' />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/cliente.css">
    <link rel="shortcut icon" type="icon/favicon" href="../img/logo_semfundo.png"/>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css"/>
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">

    <title>Cliente</title>
    
  </head>

<body>
    <?php
    session_start();
    include_once '../conexão.php';	
    include_once '../menu.php';	
    ?>
    
<center>
    <br/>
    <br/>
    <br/>
    <br/>
        <p class="text-center text-success">
			<?php 
          if(isset($_SESSION['senhaSucesso'])){
				echo $_SESSION['senhaSucesso'];
				unset($_SESSION['senhaSucesso']);
			}
          ?>
    </p>
            <br/>
    

			<?php 
                $email = $_SESSION['usuarioEmail'];
                $query = "SELECT title,start,endereco FROM eventos WHERE email =  '$email'" ;
                $result = mysqli_query($conexao, $query);
                $row = mysqli_num_rows($result);
    
                if($row > 0){

                    while ($row = mysqli_fetch_array( $result )){
                    $titulo = $row['title'];
                    $start = str_replace("/", "-", $row['start']);
                    $start = date("d-m-Y H:i:s", strtotime($start));
                    $endereco = $row['endereco'];
                    echo "<div class='container'>
                            <div class='table1'>
                                <div class='header'> 
                                    <div class='titulo'>" .$titulo. "</div></div>";  
                        echo "<ul class='list'><li>Você marcou para o dia e horário: ". $start. "</li> <div class='border'></div>";
                        echo "<li>Endereço: ". $endereco. "<br/> </li></ul>
                            </div>  
                        </div> ";
                    }
                        ?>
                
           <?php
                }else{	
                echo "<div class='container'>
                            <div class='table1'>
                                <ul class='list'> 
                                    <li> Você ainda não possui nada marcado!</li> <div class='border'></div>
                                    <li><a href='../contato/index.php'>Clique aqui para entrar em contato!</a></li>
                                </ul> 
                            </div>  
                        </div>";
                };
           ?>
    
    
    
<br/>
<a href="sair.php" class="btn btn-danger">Sair</a>

</center>


