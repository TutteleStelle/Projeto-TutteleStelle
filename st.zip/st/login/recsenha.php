<?php
session_start();
include_once '../conexão.php';

$email = $_SESSION['usuarioEmail'];

$smtpHost   = "smtp.gmail.com";
$smtpUser   = "siminitelecomunicacoes@gmail.com";
$smtpPort   = "465";
$smtpAuth   = "SSL";

require_once('../vendor/phpmailer/phpmailer/src/PHPMailer.php');
require_once('../vendor/phpmailer/phpmailer/src/SMTP.php');
require_once('../vendor/phpmailer/phpmailer/src/Exception.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer(true);

    $query = "SELECT * FROM usuarios WHERE email = '$email'";
    $result = mysqli_query($conexao, $query);
    $row = mysqli_num_rows($result);

if($row == 1){
    
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'siminitelecomunicacoes@gmail.com';
            $mail->Password = 'simini2020';
            $mail->Port = 587;

            $mail->setFrom('siminitelecomunicacoes@gmail.com');
            $mail->addAddress($email);

            $mail->isHTML(true);
            $mail->Subject = 'Recuperacao de Senha';
            $mail->Body = "Link para redefinir sua senha";
        
    
        if($mail->send()) {
            $_SESSION['emailSucesso'] = "E-mail enviado com sucesso, por favor verifique sua caixa de entrada!";
            header("Location: index.php");
                } else {
                    $_SESSION['emailErro1'] = "Email não enviado, confira seus dados";
                    header("Location: ../index.php");
                    }
        }catch (Exception $e) {
                $_SESSION['emailErro'] = "Erro ao enviar mensagem: {$mail->ErrorInfo}";
                header("Location: index.php");
                    }
    }else {
        $_SESSION['erroEmail'] = "E-mail não enviado <br/>Confira seus dados pois esse usuário não existe";
        header("Location: index.php");
}
?>

